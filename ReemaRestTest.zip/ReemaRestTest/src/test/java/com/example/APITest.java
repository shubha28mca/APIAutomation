package com.example;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import io.qameta.allure.Description;
import io.qameta.allure.restassured.AllureRestAssured;

import static io.restassured.RestAssured.*;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

public class APITest {

    private static final Logger logger = LoggerFactory.getLogger(APITest.class);

    static {
        //RestAssured.baseURI = "https://jsonplaceholder.typicode.com";
        //RestAssured.filters(new AllureRestAssured());
    }

    @BeforeAll
    public static void setup() {
        // Set base URI once for all tests
        RestAssured.baseURI = "https://jsonplaceholder.typicode.com";
        //RestAssured.baseURI = "https://jsonplaceholder.typicode.com";
        RestAssured.filters(new AllureRestAssured());
    }

    @Test
    @Description("Test to get posts and verify the response")
    public void testGetPosts() {
        logger.info("Starting test to get posts");

        given().
                when().
                get("/posts").
                then().
                statusCode(200).
                body("size()", greaterThan(0)).
                body("[0].userId", equalTo(1));

        logger.info("Completed test to get posts");
    }

    @Test
    @Description("Test to create a post and verify the response")
    public void testPostPost() {
        logger.info("Starting test to create a post");

        Response response = given().
                header("Content-Type", "application/json").
                body("{ \"title\": \"foo\", \"body\": \"bar\", \"userId\": 1 }").
                when().
                post("/posts").
                then().
                statusCode(201).
                body("title", equalTo("foo")).
                body("body", equalTo("bar")).
                body("userId", equalTo(1)).
                extract().response();

        logger.info("Response: " + response.asString());
        logger.info("Completed test to create a post");
    }

    @Test
    public void testUsernameContainsSubstring() {
        String expectedSubstring = "Leanne"; // Expected substring to check

        // Send a GET request to retrieve user details
        String username = given()
                .when()
                .get("/users/1")
                .then()
                .statusCode(200)
                .contentType(ContentType.JSON)
                .extract()
                .path("username");

        // Use user-defined function in assertion
        assertThat("Username contains the expected substring",
                usernameContainsSubstring(username, expectedSubstring),
                is(true));
    }

    // User-defined function to check if the username contains a specific substring
    private boolean usernameContainsSubstring(String username, String substring) {
        return username.contains(substring);
    }

    @Test
    public void useMultipleAssertions() {
        String expectedSubstring = "Leanne"; // Expected substring to check
        logger.info("Starting test to get response on time");

        Response response1 = given()
                .when()
                .get("/users/1")
                .then()
                .statusCode(200)
                .contentType(ContentType.JSON)
                .body("name", equalTo("Leanne Graham"))
                .body("address.geo.lat", equalTo("-37.3159"))
                .header("Content-Encoding", "gzip")
                .time(greaterThan(1000L))
                .extract().response();

        Response response = given()
                .when()
                .get("/users/1")
                .then()
                .statusCode(200)
                .contentType(ContentType.JSON)
                .body("name", equalTo("Leanne Graham"))
                .body("address.geo.lat", equalTo("-37.3159"))
                .header("Content-Encoding", "gzip")
                .time(lessThan(1000L))
                .extract().response();



        logger.info("Response: " + response.asString());
        logger.info("Completed test to get");
    }

    @Test
    @Description("Test to update a post and verify the response")
    public void testPutPost() {
        logger.info("Starting test to update a post");

        Response response = given().
                header("Content-Type", "application/json").
                body("{ \"title\": \"updated title\", \"body\": \"updated body\", \"userId\": 1 }").
                when().
                put("/posts/1").
                then().
                statusCode(200).
                body("title", equalTo("updated title")).
                body("body", equalTo("updated body")).
                body("userId", equalTo(1)).
                extract().response();

        logger.info("Response: " + response.asString());
        logger.info("Completed test to update a post");
    }

    @Test
    @Description("Test to delete a post and verify the response")
    public void testDeletePost() {
        logger.info("Starting test to delete a post");

        given().
                when().
                delete("/posts/1").
                then().
                statusCode(200);

        logger.info("Completed test to delete a post");
    }

    @Test
    @Description("Test to patch a post and verify the response")
    public void testPatchPost() {
        logger.info("Starting test to patch a post");

        Response response = given().
                header("Content-Type", "application/json").
                body("{ \"title\": \"patched title\" }").
                when().
                patch("/posts/1").
                then().
                statusCode(200).
                body("title", equalTo("patched title")).
                extract().response();

        logger.info("Response: " + response.asString());
        logger.info("Completed test to patch a post");
    }
}

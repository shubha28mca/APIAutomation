package com.example;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import io.qameta.allure.Description;
import io.qameta.allure.Step;
import io.qameta.allure.restassured.AllureRestAssured;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class AppTest {

    private static final Logger logger = LoggerFactory.getLogger(AppTest.class);

    static {
        RestAssured.baseURI = "https://jsonplaceholder.typicode.com";
        RestAssured.filters(new AllureRestAssured());
    }

    @Test
    @Description("Test to get posts and verify the response")
    public void testGetPosts() {
        logger.info("Starting test to get posts");

        given().
                when().
                get("/posts").
                then().
                statusCode(200).
                body("size()", greaterThan(0)).
                body("[0].userId", equalTo(1));

        logger.info("Completed test to get posts");
    }

    @Test
    @Description("Test to create a post and verify the response")
    public void testPostPost() {
        logger.info("Starting test to create a post");

        Response response = given().
                header("Content-Type", "application/json").
                body("{ \"title\": \"foo\", \"body\": \"bar\", \"userId\": 1 }").
                when().
                post("/posts").
                then().
                statusCode(201).
                body("title", equalTo("foo")).
                body("body", equalTo("bar")).
                body("userId", equalTo(1)).
                extract().response();

        logger.info("Response: " + response.asString());
        logger.info("Completed test to create a post");
    }
}

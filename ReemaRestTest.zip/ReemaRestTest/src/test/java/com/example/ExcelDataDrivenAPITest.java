package com.example;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import static io.restassured.RestAssured.*;

public class ExcelDataDrivenAPITest {

    private static final String EXCEL_FILE_PATH = "sample_dynamic.xlsx";

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "https://jsonplaceholder.typicode.com";
    }

    @Test
    public void testDataDrivenAPIRequests() throws IOException {
        // Create a new Excel workbook
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("UserData");

        // Create header row
        Row headerRow = sheet.createRow(0);
        headerRow.createCell(0).setCellValue("Username");
        headerRow.createCell(1).setCellValue("Password");
        headerRow.createCell(2).setCellValue("Email");

        // Add sample data
        String[][] data = {
                {"user1", "password1", "user1@example.com"},
                {"user2", "password2", "user2@example.com"},
                {"user3", "password3", "user3@example.com"}
        };

        for (int i = 0; i < data.length; i++) {
            Row row = sheet.createRow(i + 1);
            for (int j = 0; j < data[i].length; j++) {
                row.createCell(j).setCellValue(data[i][j]);
            }
        }

        // Write workbook to a file
        FileOutputStream fileOut = new FileOutputStream(EXCEL_FILE_PATH);
        workbook.write(fileOut);
        workbook.close();
        fileOut.close();

        // Iterate through Excel data and make API calls
        FileInputStream fileIn = new FileInputStream(new File(EXCEL_FILE_PATH));
        workbook = new XSSFWorkbook(fileIn);
        sheet = workbook.getSheetAt(0);

        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
            Row row = sheet.getRow(i);
            String username = row.getCell(0).getStringCellValue();
            String password = row.getCell(1).getStringCellValue();
            String email = row.getCell(2).getStringCellValue();

            // Example of using the data in an API request
            given()
                    .contentType(ContentType.JSON)
                    .body("{ \"username\": \"" + username + "\", \"password\": \"" + password + "\", \"email\": \"" + email + "\" }")
                    .when()
                    .post("/users")
                    .then()
                    .statusCode(201);

            // You can add more assertions or logging as needed
        }

        workbook.close();
        fileIn.close();
    }

    @AfterAll
    public static void cleanup() {
        // Delete the Excel file after tests are done
        File file = new File(EXCEL_FILE_PATH);
        if (file.exists()) {
            if (file.delete()) {
                System.out.println("Deleted Excel file: " + EXCEL_FILE_PATH);
            } else {
                System.out.println("Failed to delete Excel file: " + EXCEL_FILE_PATH);
            }
        }
    }
}

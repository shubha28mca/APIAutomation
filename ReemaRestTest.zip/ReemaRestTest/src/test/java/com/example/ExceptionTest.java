import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class ExceptionTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "https://jsonplaceholder.typicode.com";
    }

    @Test
    public void testNonExistingResource() {
        // Send a GET request to a non-existing endpoint
        given()
                .when()
                .get("/non_existing_endpoint")
                .then()
                .statusCode(404); // Expected status code for resource not found
    }

    @Test
    public void testHandleException() {
        try {
            // Send a GET request to retrieve user details with non-existent user ID
            given()
                    .when()
                    .get("/users/1000")
                    .then()
                    .statusCode(404); // Expected status code for resource not found
        } catch (Exception e) {
            // Handle any exceptions thrown during the test execution
            e.printStackTrace();
        }
    }

    @Test
    public void testExceptionWithResponse() {
        // Send a GET request to retrieve user details with non-existent user ID
        Response response = given()
                .when()
                .get("/users/1000");

        // Handle exception based on response status code
        if (response.getStatusCode() == 404) {
            System.out.println("User not found: " + response.getBody().asString());
        } else {
            System.out.println("Unexpected response: " + response.getBody().asString());
        }
    }

    @Test
    public void testHandleNullPointerException() {
        try {
            String userId = given()
                    .when()
                    .get("/users/1")
                    .then()
                    .extract()
                    .path("nonExistingField"); // Simulating accessing a non-existing field

            if (userId != null) {
                // Proceed with further operations
                System.out.println("User ID: " + userId);
            } else {
                System.out.println("User ID not found");
            }
        } catch (NullPointerException e) {
            // Handle NullPointerException
            e.printStackTrace();
        }
    }
}

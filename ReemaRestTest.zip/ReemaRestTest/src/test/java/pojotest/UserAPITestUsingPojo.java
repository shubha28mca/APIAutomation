package pojotest;

import com.fasterxml.jackson.core.JsonProcessingException;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.*;
import com.fasterxml.jackson.databind.ObjectMapper;

public class UserAPITestUsingPojo {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "https://jsonplaceholder.typicode.com";
    }

    @Test
    public void testCreateUser() {
        Address address = new Address();
        address.setStreet("123 Elm St");
        address.setCity("Springfield");
        address.setZipcode("12345");

        User user = new User();
        user.setId(1);
        user.setUsername("johndoe");
        user.setEmail("johndoe@example.com");
        user.setAddress(address);

        given()
                .contentType(ContentType.JSON)
                .body(user) // Pass the POJO directly as the body
                .when()
                .post("/users")
                .then()
                .statusCode(201);
    }

    @Test
    public void testGetUserById() {
        // Send GET request to retrieve user information
        Response response = get("/users/1");
        try {
            // Deserialize JSON response to User POJO using Jackson ObjectMapper
            ObjectMapper objectMapper = new ObjectMapper();
            UserAddress user = objectMapper.readValue(response.asString(), UserAddress.class);

            // Validate the deserialized User object
            System.out.println("User ID: " + user.getId());
            System.out.println("Username: " + user.getUsername());
            System.out.println("Email: " + user.getEmail());
            System.out.println("Address: " + user.getAddress().getStreet() + ", " +
                    user.getAddress().getCity() + ", " +
                    user.getAddress().getZipcode());

            // Add assertions as needed
        } catch (JsonProcessingException e) {
            e.printStackTrace(); // Handle or log the exception
        }

    }
}

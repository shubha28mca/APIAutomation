package pojotest;

import com.fasterxml.jackson.annotation.JsonProperty;

public class UserAddress {
    private int id;
    private String name;
    private String username;
    private String email;
    private Address address;
    private String phone;
    private String website;
    private Company company;

    // Getters and Setters for all fields

    @JsonProperty("id")
    public int getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(int id) {
        this.id = id;
    }

    @JsonProperty("name")
    public String getName() {
        return name;
    }

    @JsonProperty("name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("username")
    public String getUsername() {
        return username;
    }

    @JsonProperty("username")
    public void setUsername(String username) {
        this.username = username;
    }

    @JsonProperty("email")
    public String getEmail() {
        return email;
    }

    @JsonProperty("email")
    public void setEmail(String email) {
        this.email = email;
    }

    @JsonProperty("address")
    public Address getAddress() {
        return address;
    }

    @JsonProperty("address")
    public void setAddress(Address address) {
        this.address = address;
    }

    @JsonProperty("phone")
    public String getPhone() {
        return phone;
    }

    @JsonProperty("phone")
    public void setPhone(String phone) {
        this.phone = phone;
    }

    @JsonProperty("website")
    public String getWebsite() {
        return website;
    }

    @JsonProperty("website")
    public void setWebsite(String website) {
        this.website = website;
    }

    @JsonProperty("company")
    public Company getCompany() {
        return company;
    }

    @JsonProperty("company")
    public void setCompany(Company company) {
        this.company = company;
    }

    // Nested class definitions for Address and Company

    public static class Address {
        private String street;
        private String suite;
        private String city;
        private String zipcode;
        private Geo geo;

        // Getters and Setters for Address fields

        @JsonProperty("street")
        public String getStreet() {
            return street;
        }

        @JsonProperty("street")
        public void setStreet(String street) {
            this.street = street;
        }

        @JsonProperty("suite")
        public String getSuite() {
            return suite;
        }

        @JsonProperty("suite")
        public void setSuite(String suite) {
            this.suite = suite;
        }

        @JsonProperty("city")
        public String getCity() {
            return city;
        }

        @JsonProperty("city")
        public void setCity(String city) {
            this.city = city;
        }

        @JsonProperty("zipcode")
        public String getZipcode() {
            return zipcode;
        }

        @JsonProperty("zipcode")
        public void setZipcode(String zipcode) {
            this.zipcode = zipcode;
        }

        @JsonProperty("geo")
        public Geo getGeo() {
            return geo;
        }

        @JsonProperty("geo")
        public void setGeo(Geo geo) {
            this.geo = geo;
        }
    }

    public static class Geo {
        private String lat;
        private String lng;

        // Getters and Setters for Geo fields

        @JsonProperty("lat")
        public String getLat() {
            return lat;
        }

        @JsonProperty("lat")
        public void setLat(String lat) {
            this.lat = lat;
        }

        @JsonProperty("lng")
        public String getLng() {
            return lng;
        }

        @JsonProperty("lng")
        public void setLng(String lng) {
            this.lng = lng;
        }
    }

    public static class Company {
        private String name;
        private String catchPhrase;
        private String bs;

        // Getters and Setters for Company fields

        @JsonProperty("name")
        public String getName() {
            return name;
        }

        @JsonProperty("name")
        public void setName(String name) {
            this.name = name;
        }

        @JsonProperty("catchPhrase")
        public String getCatchPhrase() {
            return catchPhrase;
        }

        @JsonProperty("catchPhrase")
        public void setCatchPhrase(String catchPhrase) {
            this.catchPhrase = catchPhrase;
        }

        @JsonProperty("bs")
        public String getBs() {
            return bs;
        }

        @JsonProperty("bs")
        public void setBs(String bs) {
            this.bs = bs;
        }
    }
}
